// Automatically Generated -- DO NOT EDIT
// com.vcloudairshare.shared.request.VMwareBlogsRequestFactory
package com.vcloudairshare.shared.request;
import java.util.Arrays;
import com.google.web.bindery.requestfactory.vm.impl.OperationData;
import com.google.web.bindery.requestfactory.vm.impl.OperationKey;
import com.google.gwt.core.shared.GwtIncompatible;
@GwtIncompatible("Server-side only but loaded through naming convention so must be in same package as shared VMwareBlogsRequestFactory interface")
public final class VMwareBlogsRequestFactoryDeobfuscatorBuilder extends com.google.web.bindery.requestfactory.vm.impl.Deobfuscator.Builder {
{
withOperation(new OperationKey("EDaJzdRqDdyJFWdTAnApBLHVPIw="),
  new OperationData.Builder()
  .withClientMethodDescriptor("(IILcom/vcloudairshare/shared/enumeration/MachineType;Lcom/vcloudairshare/shared/enumeration/Status;)Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("(IILcom/vcloudairshare/shared/enumeration/MachineType;Lcom/vcloudairshare/shared/enumeration/Status;)Ljava/util/List;")
  .withMethodName("findByAvialable")
  .withRequestContext("com.vcloudairshare.shared.request.VirtualMacineRequest")
  .build());
withOperation(new OperationKey("RjvLb40moJInXfJXxpnnq3WHZoQ="),
  new OperationData.Builder()
  .withClientMethodDescriptor("(Ljava/lang/Long;)Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("(Ljava/lang/Long;)Lcom/vcloudairshare/server/datastore/entity/VirtualMachine;")
  .withMethodName("findById")
  .withRequestContext("com.vcloudairshare.shared.request.VirtualMacineRequest")
  .build());
withOperation(new OperationKey("$LwH7HKv0HiEL0Ww37P2dIcU384="),
  new OperationData.Builder()
  .withClientMethodDescriptor("(IILcom/vcloudairshare/shared/enumeration/MachineType;Lcom/vcloudairshare/shared/enumeration/Status;)Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("(IILcom/vcloudairshare/shared/enumeration/MachineType;Lcom/vcloudairshare/shared/enumeration/Status;)Lcom/vcloudairshare/server/datastore/entity/VirtualMachine;")
  .withMethodName("findFirstByAvialable")
  .withRequestContext("com.vcloudairshare.shared.request.VirtualMacineRequest")
  .build());
withOperation(new OperationKey("076lLk9wyQbcQqakKGs7wyyFQV0="),
  new OperationData.Builder()
  .withClientMethodDescriptor("(Ljava/lang/String;Ljava/lang/String;)Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("(Ljava/lang/String;Ljava/lang/String;)Lcom/vcloudairshare/server/datastore/entity/Users;")
  .withMethodName("findByCredential")
  .withRequestContext("com.vcloudairshare.shared.request.UserRequest")
  .build());
withOperation(new OperationKey("dUa44HACl4LHnoxQ8NAmnYMIzBI="),
  new OperationData.Builder()
  .withClientMethodDescriptor("(Ljava/lang/Long;)Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("(Ljava/lang/Long;)Lcom/vcloudairshare/server/datastore/entity/Users;")
  .withMethodName("findById")
  .withRequestContext("com.vcloudairshare.shared.request.UserRequest")
  .build());
withRawTypeToken("Eu6pUV9rs7fE0lkxqTUzX14krmI=", "com.vcloudairshare.shared.proxy.UserDTO");
withRawTypeToken("5V2r3aL4ojKFgY15WwfIMlLCFzk=", "com.vcloudairshare.shared.proxy.VirtualMachineDTO");
withRawTypeToken("w1Qg$YHpDaNcHrR5HZ$23y518nA=", "com.google.web.bindery.requestfactory.shared.EntityProxy");
withRawTypeToken("FXHD5YU0TiUl3uBaepdkYaowx9k=", "com.google.web.bindery.requestfactory.shared.BaseProxy");
withClientToDomainMappings("com.vcloudairshare.server.datastore.entity.Users", Arrays.asList("com.vcloudairshare.shared.proxy.UserDTO"));
withClientToDomainMappings("com.vcloudairshare.server.datastore.entity.VirtualMachine", Arrays.asList("com.vcloudairshare.shared.proxy.VirtualMachineDTO"));
}}
