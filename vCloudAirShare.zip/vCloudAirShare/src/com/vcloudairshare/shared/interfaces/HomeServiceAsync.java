package com.vcloudairshare.shared.interfaces;



public interface HomeServiceAsync {
//	void authentication(String username, String pass, AsyncCallback<UserDTO> callback)
//			throws IllegalArgumentException;
}