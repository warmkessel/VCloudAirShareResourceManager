package com.vcloudairshare.client.resource;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface ImageBundle extends ClientBundle{


  
  @Source("community_off.jpg")
  ImageResource communityOff();
  
}
