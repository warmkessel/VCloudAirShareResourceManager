package com.vcloudairshare.client.event;

import com.google.gwt.event.shared.EventHandler;
  public interface ResizeEventHandler extends EventHandler {
    void onMessageReceived(ResizeEvent event);
}