package com.vcloudairshare.client.view.home;

import com.google.gwt.place.shared.Place;

public class HomePlace extends Place {

	public HomePlace() {
	}
}