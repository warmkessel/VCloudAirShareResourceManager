package com.vcloudairshare.client.view.login;

import com.google.gwt.place.shared.Place;

public class LoginPlace extends Place {

	public LoginPlace() {
	}
}