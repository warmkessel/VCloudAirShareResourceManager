package com.vcloudairshare.client.view.failure;

import com.google.gwt.place.shared.Place;

public class FailurePlace extends Place {

	public FailurePlace() {
	}
}