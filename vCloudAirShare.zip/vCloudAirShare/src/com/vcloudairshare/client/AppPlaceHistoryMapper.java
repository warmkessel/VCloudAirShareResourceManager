package com.vcloudairshare.client;

import com.google.gwt.place.shared.PlaceHistoryMapper;

public interface AppPlaceHistoryMapper extends PlaceHistoryMapper
	{
}